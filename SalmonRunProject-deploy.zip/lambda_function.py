import boto3
import json
import base64
from os import environ
import urllib.parse
import logging
import requests


clientssm = boto3.client('ssm')
s3 = boto3.client('s3')
salmonid = ["SteelHead", "Flyfish", "Maws", "Fish Stick", "Drizzler", "Slammin' Lid", 
    "Flipper-Flopper", "Big Shot", "Stinger", "Scrapper", "Steel Eel"]
    
steelhead = clientssm.get_parameter(Name='SteelHead')
flyfish = clientssm.get_parameter(Name='Flyfish')
maws =  clientssm.get_parameter(Name='Maws')
fishstick =  clientssm.get_parameter(Name='FishStick')
drizzler = clientssm.get_parameter(Name='Drizzler')
slamminlid = clientssm.get_parameter(Name='SlamminLid') 
flipperflopper = clientssm.get_parameter(Name='FlipperFlopper')
bigshot = clientssm.get_parameter(Name='BigShot')
stinger = clientssm.get_parameter(Name='Stinger')
scrapper = clientssm.get_parameter(Name='Scrapper')
steeleel = clientssm.get_parameter(Name='SteelEel') 
    

def lambda_handler(event, context):
    
    bucket='salmonrunproject'
    key='IMG_7110.jpg'
    
    upload_to_s3()
    text_list=detect_salmonid_textract(bucket, key)
    body_str = format_response(text_list)
    print(body_str)
    print ('finished----------\n')
    return {
        'statusCode' : 200, 
        'body': body_str
    }
    

def upload_to_s3():
    image = 'IMG_7110.jpg'
    
    # 1) generate presigned URL of S3
    response = s3.generate_presigned_post(
        Bucket='salmonrunproject',
        Key=image,
        ExpiresIn=10
        )
        
    # 2) upload the file to S3 using the presigned URL
    files = {'file': open(image, 'rb')}
    r = requests.post(response['url'], data=response['fields'], files=files)
    print(r.status_code)
    
    print(response)

    

def detect_salmonid_textract(bucket, key):
    
    client=boto3.client('textract')
    list_of_texts = []
        
    doc = {'S3Object':{'Bucket':bucket,'Name':key}}

    response=client.detect_document_text(Document=doc)

    for block in response['Blocks']:
        for b in block:
            if (b =='Text'):
                list_of_texts.append(block['Text'])
          
    return list_of_texts


def format_response(text_list):
    i = 0
    list_len = len(text_list)
    
    steelhead_second = False
    flyfish_second = False
    maws_second = False
    drizzler_second = False
    fishstick_second = False
    slamminlid_second = False
    flipperflopper_second = False
    bigshot_second = False
    stinger_second = False
    scrapper_second = False
    steeleel_second = False
    
    str = ''

    for text in text_list:
        match text:
            case "Steelhead":
                if not steelhead_second:
                    steelhead_second = True
                    print("First Time")
                    j = i + 1
                    str += search_count(j, list_len, text_list, "SteelHead", steelhead['Parameter']['Value'])

            case "Flyfish":
                if not flyfish_second:
                    flyfish_second = True
                    j = i + 1
                    str += search_count(j, list_len, text_list, "Flyfish", flyfish['Parameter']['Value'])
            case "Maws":
                if not maws_second:
                    maws_second = True
                    j = i + 1
                    str += search_count(j, list_len, text_list, "Maws", maws['Parameter']['Value'])
            case "Fish Stick":
                if not fishstick_second:
                    fishstick_second = True
                    j = i + 1
                    str += search_count(j, list_len, text_list, "FishStick", fishstick['Parameter']['Value'])
            case "Drizzler": 
                if not drizzler_second:
                    drizzler_second = True
                    j = i + 1
                    str += search_count(j, list_len, text_list, "Drizzler", drizzler['Parameter']['Value'])

            case "Slammin' Lid": 
                if not slamminlid_second:
                    slamminlid_second = True
                    j = i + 1
                    str += search_count(j, list_len, text_list, "SlamminLid", slamminlid['Parameter']['Value']) 
            case "Flipper-Flopper":
                if not flipperflopper_second:
                    flipperflopper_second = True
                    j = i + 1
                    str += search_count(j, list_len, text_list, "FlipperFlopper", flipperflopper['Parameter']['Value'])
            case "Big Shot":
                if not bigshot_second:
                    bigshot_second = True
                    j = i + 1
                    str += search_count(j, list_len, text_list, "BigShot", bigshot['Parameter']['Value'])
            case "Stinger":
                if not stinger_second:
                    stinger_second = True
                    j = i + 1
                    str += search_count(j, list_len, text_list, "Stinger", stinger['Parameter']['Value'])
            case "Scrapper":
                if not scrapper_second:
                    scrapper_second = True
                    j = i + 1
                    str += search_count(j, list_len, text_list, "Scrapper", scrapper['Parameter']['Value'])
            case "Steel Eel":
                if not steeleel_second:
                    steeleel_second = True
                    second = True
                    j = i + 1
                    str += search_count(j, list_len, text_list, "SteelEel", steeleel['Parameter']['Value'])                  
    
        i += 1
    return str
    

### format_response helper methods  
    
def search_count(j, list_len, text_list, name, param_val):
    
    while j < list_len and text_list[j] not in salmonid:
        
        if "(" in text_list[j]:
            
            pos = text_list[j].index("(")
            count = int(param_val) + int(text_list[j][pos+1])
            clientssm.put_parameter(Name=name, Overwrite=True, Value=str(count))
            return (f"you've splatted {count} {name}.\n")
        
        else:
            return ""
        
    return(count)